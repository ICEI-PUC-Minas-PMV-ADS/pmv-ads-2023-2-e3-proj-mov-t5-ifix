export const colors = {
  primary: '#FFA611',
  primaryDark: '#F5820D',
};
